#include <stdio.h>
int main(){
    int n;
    scanf("%d", &n);
    int x = ~n;
    
    return 0;
}